class Item {
  String namaItem;
  Item(this.namaItem);
}
