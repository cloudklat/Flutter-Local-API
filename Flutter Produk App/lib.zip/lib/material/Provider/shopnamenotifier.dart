import 'package:flutter/material.dart';

class ShopNameNotifier extends ChangeNotifier {
  //
  String namaToko = '';

  updateShopName(String shopName) async {
    this.namaToko = shopName;
    notifyListeners();
  }
}
