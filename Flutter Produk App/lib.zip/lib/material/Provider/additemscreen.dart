import 'package:flutter/material.dart';
import 'package:flutterv1/material/Provider/itemaddnotifier.dart';
import 'package:flutterv1/material/Provider/shopnamenotifier.dart';
import 'package:provider/provider.dart';

class TambahItemScreen extends StatelessWidget {
  //
  TambahItemScreen() : super();

  final String title = 'Tambah Produk';

  final TextEditingController _itemNameController = TextEditingController();
  final TextEditingController _shopNameController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          title,
        ),
      ),
      body: Container(
        padding: EdgeInsets.all(30.0),
        child: Column(
          children: <Widget>[
            TextField(
              controller: _itemNameController,
              decoration: InputDecoration(
                contentPadding: EdgeInsets.all(15.0),
                hintText: 'Ketik Nama Produk..',
              ),
            ),
            SizedBox(
              height: 20.0,
            ),
            ElevatedButton(
              child: Text('TAMBAH PRODUK'),
              onPressed: () async {
                if (_itemNameController.text.isEmpty) {
                  return;
                }
                await Provider.of<ItemAddNotifier>(context, listen: false)
                    .addItem(_itemNameController.text);
                Navigator.pop(context);
              },
            ),
            SizedBox(
              height: 20.0,
            ),
            ElevatedButton(
              child: Text('TAMBAH TAB ITEM'),
              onPressed: () async {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    fullscreenDialog: true,
                    builder: (context) {
                      return TambahItemScreen();
                    },
                  ),
                );
              },
            ),
            TextField(
              controller: _shopNameController,
              decoration: InputDecoration(
                contentPadding: EdgeInsets.all(15.0),
                hintText: 'Judul Nama Toko..',
              ),
            ),
            ElevatedButton(
              child: Text('Ganti Nama Toko'),
              onPressed: () async {
                if (_shopNameController.text.isEmpty) {
                  return;
                }
                await Provider.of<ShopNameNotifier>(context, listen: false)
                    .updateShopName(_shopNameController.text);
                Navigator.pop(context);
              },
            ),
          ],
        ),
      ),
    );
  }
}
