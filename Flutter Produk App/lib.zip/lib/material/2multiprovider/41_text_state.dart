import 'package:flutter/material.dart';

class TextProvider extends ChangeNotifier {
  String _text = "Hello";

  String get text => _text;

  void updateText(String newText) {
    _text = newText;
    notifyListeners();
  }
}
